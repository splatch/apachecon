package eu.apachecon.camel.cdi.demo1.svc;


public interface Service {

    String sayHello(String name);

}
