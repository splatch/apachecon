package com.apachecon.eu2012.camel_cdi;

public interface Greeter {

    String greet(String who);

}
